# Desafío 4 — Menú principal (Fabric 1.21.1) · created by sefix  ·  v1.1.0

Pantalla de título animada:
- Fondo: tu GIF **completo** (sin recortes). Si la pantalla es más ancha, el espacio de la izquierda se rellena con el mismo cielo.
- Ruleta con **truenos rojos animados** (al azar, ráfagas y una corriente que le da vueltas al borde).
- Botones **JUGAR / OPCIONES / SALIR** (crecen y brillan con el mouse). **JUGAR abre la lista de servidores.**
- Abajo a la derecha: **created by SEFIX** con brillo que le cruza las letras.

## Cómo sacar el .jar

> Se compila con Java 21 (JDK, no solo JRE).

### Opción A — GitHub (sin instalar nada, sirve desde el cel)
1. Sube el zip a tu repo (Add file → Upload files).
2. Pestaña **Actions** → workflow **build** → abre la última ejecución → baja el artefacto `desafio4-menu-jar`.
   (Si extraes el zip y subes los archivos tal cual, el workflow `.github/workflows/build.yml` ya viene incluido.)

### Opción B — Windows
1. Instala **Temurin JDK 21**: https://adoptium.net
2. Descomprime esta carpeta y dale doble clic a `build.bat`.
3. El .jar queda en `build\libs\desafio4-menu-1.1.0.jar`

### Opción C — Linux / Mac
`./build.sh`

## Instalar
Copia el .jar a `.minecraft/mods` (borra antes cualquier versión vieja de este mod).
Necesitas **Fabric Loader** y **Fabric API** para 1.21.1.

## Personalizar
- Imágenes: `src/main/resources/assets/desafio4_menu/textures/gui/`
  (`logo.png`, `btn_*.png`, `credit.png`, `bg/f000.png … f039.png`, `bg_left.png`, `bolt_00.png … bolt_15.png`).
- Posiciones y tamaños: constantes al inicio de `Desafio4TitleScreen.java`
  (`COL_X`, `LOGO_SIZE`, `LOGO_CY`, `BTN_K`, `CREDIT_SIZE`, y los `yFrac` de cada botón).
- Si algo falla al dibujar, el mod vuelve solo al menú normal de Minecraft en vez de cerrar el juego.

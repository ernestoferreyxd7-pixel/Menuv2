#!/usr/bin/env bash
# Compila el mod (Linux / macOS). Necesita JDK 21 instalado.
set -e
cd "$(dirname "$0")"
GRADLE_VERSION=8.10.2
ROOT="$HOME/.desafio4-gradle"
BIN="$ROOT/gradle-$GRADLE_VERSION/bin/gradle"

if [ -z "$JAVA_HOME" ] && ! command -v javac >/dev/null 2>&1; then
  echo "[!] No encuentro el JDK 21. Instala Temurin JDK 21 (https://adoptium.net)."
  exit 1
fi

if [ ! -x "$BIN" ]; then
  echo "Descargando Gradle $GRADLE_VERSION (solo la primera vez)..."
  mkdir -p "$ROOT"
  curl -L "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ROOT/gradle.zip"
  unzip -q -o "$ROOT/gradle.zip" -d "$ROOT"
fi

"$BIN" build
echo
echo "LISTO! Tu mod esta en: $(pwd)/build/libs/desafio4-menu-1.0.0.jar"

@echo off
setlocal
cd /d "%~dp0"
set "GRADLE_VERSION=8.10.2"
set "GRADLE_ROOT=%USERPROFILE%\.desafio4-gradle"
set "GRADLE_BIN=%GRADLE_ROOT%\gradle-%GRADLE_VERSION%\bin\gradle.bat"

if not defined JAVA_HOME (
  where javac >nul 2>nul
  if errorlevel 1 (
    echo [!] No encuentro el JDK 21. Instala "Temurin JDK 21" desde https://adoptium.net
    echo     y vuelve a abrir este archivo.
    pause
    exit /b 1
  )
)

if not exist "%GRADLE_BIN%" (
  echo Descargando Gradle %GRADLE_VERSION% - solo la primera vez...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; New-Item -ItemType Directory -Force -Path '%GRADLE_ROOT%' | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ROOT%\gradle.zip'; Expand-Archive -Force -Path '%GRADLE_ROOT%\gradle.zip' -DestinationPath '%GRADLE_ROOT%'"
  if errorlevel 1 (
    echo [!] No pude descargar Gradle. Revisa tu internet.
    pause
    exit /b 1
  )
)

call "%GRADLE_BIN%" build
if errorlevel 1 (
  echo [!] Fallo la compilacion. Copia el error y mandamelo.
  pause
  exit /b 1
)

echo.
echo LISTO! Tu mod esta en la carpeta build\libs  (el archivo desafio4-menu-1.0.0.jar)
explorer "%~dp0build\libs"
pause

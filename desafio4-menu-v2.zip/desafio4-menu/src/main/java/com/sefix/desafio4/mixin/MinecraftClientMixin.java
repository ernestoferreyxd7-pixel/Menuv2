package com.sefix.desafio4.mixin;

import com.sefix.desafio4.Desafio4TitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

	/** Cada vez que el juego quiere abrir el menu normal, abrimos el nuestro. */
	@ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
	private Screen desafio4$replaceTitleScreen(Screen screen) {
		if (screen != null && screen.getClass() == TitleScreen.class && !Desafio4TitleScreen.isBroken()) {
			return new Desafio4TitleScreen();
		}
		return screen;
	}
}

package com.sefix.desafio4;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.RotationAxis;

/**
 * Menu principal estilo "Desafio 4" (created by sefix).
 * Fondo animado completo (frames del GIF), ruleta con truenos rojos animados,
 * botones JUGAR (servidores) / OPCIONES / SALIR y creditos estilizados.
 */
public class Desafio4TitleScreen extends Screen {

	// ------------------------------------------------------------------
	// Medidas de los assets (las genera el script de assets)
	// ------------------------------------------------------------------
	private static final int BG_W = 800;
	private static final int BG_H = 442;
	private static final int BG_FRAMES = 40;
	private static final long BG_FRAME_MS = 80L;
	private static final float BG_BRIGHT = 1.10F;

	// extension del fondo a la izquierda (para pantallas mas anchas que el GIF)
	private static final int EXT_W = 376;
	private static final int EXT_H = 221;
	private static final int EXT_FEATHER = 26;
	private static final float EXT_SCALE = 2F;       // pixeles del GIF por pixel de la textura
	private static final int EXT_FILL = 0xFF0D081A;  // relleno si la pantalla es ultra ancha

	private static final int LOGO_W = 1024;
	private static final int LOGO_H = 988;
	private static final float WHEEL_CX = 513F;      // centro de la ruleta dentro de logo.png
	private static final float WHEEL_CY = 477F;

	private static final int CREDIT_W = 450;
	private static final int CREDIT_H = 153;

	// ------------------------------------------------------------------
	// Posiciones (fracciones de la pantalla) - igual que la foto de referencia
	// ------------------------------------------------------------------
	private static final float COL_X = 0.265F;      // centro de la columna (ancho)
	private static final float LOGO_SIZE = 0.46F;   // ancho de la ruleta (alto de pantalla)
	private static final float LOGO_CY = 0.335F;    // centro vertical de la ruleta
	private static final float BTN_K = 0.00032F;    // tamano de botones
	private static final float CREDIT_SIZE = 0.26F; // ancho de los creditos (alto de pantalla)

	private static final int FRAMES_PER_RENDER = 2; // carga progresiva del fondo

	// ------------------------------------------------------------------
	// Truenos
	// ------------------------------------------------------------------
	private static final int BOLT_COUNT = 16;
	private static final int BOLT_SIZE = 512;        // 512 px del sprite = 1024 px de la ruleta
	private static final int G_RADIAL = 0;
	private static final int N_RADIAL = 7;
	private static final int G_RIM = 7;
	private static final int N_RIM = 5;
	private static final int G_SKULL = 12;
	private static final int N_SKULL = 4;
	private static final int LANES = 8;
	private static final float[] LANE_PERIOD = {0.62F, 0.83F, 0.71F, 1.05F, 0.58F, 0.94F, 0.77F, 1.12F};
	private static final float[] LANE_OFFSET = {0.00F, 0.31F, 0.17F, 0.52F, 0.43F, 0.09F, 0.66F, 0.25F};
	private static final int MAX_BOLTS = 20;

	// brillo que cruza los creditos
	private static final float SHINE_PERIOD = 5.5F;
	private static final float SHINE_DUR = 0.95F;
	private static final float[] SHINE_WIDTH = {0.20F, 0.11F, 0.05F};
	private static final float[] SHINE_ALPHA = {0.30F, 0.50F, 0.80F};

	private static final String NS = Desafio4Mod.MOD_ID;
	private static final Identifier LOGO = Identifier.of(NS, "textures/gui/logo.png");
	private static final Identifier BG_LEFT = Identifier.of(NS, "textures/gui/bg_left.png");
	private static final Identifier CREDIT = Identifier.of(NS, "textures/gui/credit.png");
	private static final Identifier TEX_JUGAR = Identifier.of(NS, "textures/gui/btn_jugar.png");
	private static final Identifier TEX_OPCIONES = Identifier.of(NS, "textures/gui/btn_opciones.png");
	private static final Identifier TEX_SALIR = Identifier.of(NS, "textures/gui/btn_salir.png");
	private static final Identifier[] BG = new Identifier[BG_FRAMES];
	private static final Identifier[] BOLTS = new Identifier[BOLT_COUNT];

	static {
		for (int i = 0; i < BG_FRAMES; i++) {
			BG[i] = Identifier.of(NS, String.format(Locale.ROOT, "textures/gui/bg/f%03d.png", i));
		}
		for (int i = 0; i < BOLT_COUNT; i++) {
			BOLTS[i] = Identifier.of(NS, String.format(Locale.ROOT, "textures/gui/bolt_%02d.png", i));
		}
	}

	private static volatile boolean broken = false;

	/** true si la pantalla fallo alguna vez (entonces se usa el menu normal de Minecraft). */
	public static boolean isBroken() {
		return broken;
	}

	// ------------------------------------------------------------------
	// Botones
	// ------------------------------------------------------------------
	private static final class Btn {
		final Identifier tex;
		final int tw;
		final int th;
		final float yFrac;
		final int rgb;
		final Runnable action;
		float hover;

		Btn(Identifier tex, int tw, int th, float yFrac, int rgb, Runnable action) {
			this.tex = tex;
			this.tw = tw;
			this.th = th;
			this.yFrac = yFrac;
			this.rgb = rgb;
			this.action = action;
		}
	}

	private final Btn[] btns;
	private final long startMs;
	private long lastMs;
	private int framesLoaded = 0;
	private boolean failed = false;

	// truenos activos en este frame
	private int boltN = 0;
	private final int[] bVar = new int[MAX_BOLTS];
	private final float[] bAng = new float[MAX_BOLTS];
	private final float[] bScale = new float[MAX_BOLTS];
	private final float[] bAlpha = new float[MAX_BOLTS];
	private final float[] bBright = new float[MAX_BOLTS];

	public Desafio4TitleScreen() {
		super(Text.literal("Desafio 4"));
		this.startMs = Util.getMeasuringTimeMs();
		this.lastMs = this.startMs;
		this.btns = new Btn[] {
			new Btn(TEX_JUGAR, 518, 96, 0.625F, 0xEE5B57, this::onPlay),
			new Btn(TEX_OPCIONES, 738, 96, 0.756F, 0xFDFC56, this::onOptions),
			new Btn(TEX_SALIR, 435, 96, 0.889F, 0x59EF5B, this::onQuit)
		};
	}

	// ------------------------------------------------------------------
	// Acciones de los botones
	// ------------------------------------------------------------------
	/** JUGAR -> lista de servidores. */
	private void onPlay() {
		this.client.setScreen(new MultiplayerScreen(this));
	}

	private void onOptions() {
		this.client.setScreen(new OptionsScreen(this, this.client.options));
	}

	private void onQuit() {
		this.client.scheduleStop();
	}

	// ------------------------------------------------------------------
	// Pantalla
	// ------------------------------------------------------------------
	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (this.failed) {
			return;
		}
		try {
			drawAll(context, mouseX, mouseY);
		} catch (Throwable error) {
			this.failed = true;
			broken = true;
			Desafio4Mod.LOGGER.error("Fallo al dibujar el menu Desafio 4, vuelvo al menu normal", error);
			final MinecraftClient mc = this.client;
			mc.execute(() -> mc.setScreen(new TitleScreen()));
		}
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0 && (Util.getMeasuringTimeMs() - this.startMs) > 900L) {
			for (Btn b : this.btns) {
				if (isOver(b, mouseX, mouseY)) {
					this.client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
					b.action.run();
					return true;
				}
			}
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private boolean isOver(Btn b, double mx, double my) {
		float h = this.height;
		float k = h * BTN_K;
		float cx = this.width * COL_X;
		float cy = h * b.yFrac;
		float halfW = b.tw * k * 0.5F + h * 0.025F;
		float halfH = b.th * k * 0.5F + h * 0.022F;
		return Math.abs(mx - cx) <= halfW && Math.abs(my - cy) <= halfH;
	}

	// ------------------------------------------------------------------
	// Dibujo
	// ------------------------------------------------------------------
	private void drawAll(DrawContext ctx, int mouseX, int mouseY) {
		long now = Util.getMeasuringTimeMs();
		float t = (now - this.startMs) / 1000.0F;
		float dt = Math.min(0.1F, (now - this.lastMs) / 1000.0F);
		this.lastMs = now;

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		drawBackground(ctx, now - this.startMs);
		drawLogo(ctx, t);
		drawButtons(ctx, mouseX, mouseY, t, dt);
		drawCredit(ctx, t);
		drawFade(ctx, t);

		ctx.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		RenderSystem.disableBlend();
	}

	/**
	 * Fondo: el GIF COMPLETO (a toda la altura, sin recortes), pegado a la derecha.
	 * Si la pantalla es mas ancha que el GIF, el espacio de la izquierda se rellena con una
	 * extension suave del mismo cielo. Fundido suave entre frames.
	 */
	private void drawBackground(DrawContext ctx, long elapsedMs) {
		float w = this.width;
		float h = this.height;

		// carga progresiva de frames (evita un tiron al abrir el menu)
		TextureManager tm = this.client.getTextureManager();
		int loadedNow = 0;
		while (this.framesLoaded < BG_FRAMES && loadedNow < FRAMES_PER_RENDER) {
			tm.getTexture(BG[this.framesLoaded]);
			this.framesLoaded++;
			loadedNow++;
		}

		double pos = elapsedMs / (double) BG_FRAME_MS;
		long whole = (long) Math.floor(pos);
		float frac = (float) (pos - whole);
		int a = (int) (whole % BG_FRAMES);
		int b = (a + 1) % BG_FRAMES;
		if (a >= this.framesLoaded) {
			a = this.framesLoaded - 1;
			frac = 0F;
		}
		boolean crossfade = frac > 0.01F && b < this.framesLoaded;

		float s = h / BG_H;          // el alto del GIF = alto de la pantalla (se ve completo)
		float dw = BG_W * s;
		float x0 = w - dw;           // > 0: sobra espacio a la izquierda

		float ex = 0F;
		float es = EXT_SCALE * s;
		if (x0 > 0.5F) {
			ex = x0 + EXT_FEATHER * es - EXT_W * es;
			if (ex > 0.5F) {
				ctx.fill(0, 0, (int) Math.ceil(ex) + 1, this.height, EXT_FILL);
			}
		}

		MatrixStack m = ctx.getMatrices();
		m.push();
		m.translate(x0, 0F, 0F);
		m.scale(s, s, 1F);
		ctx.setShaderColor(BG_BRIGHT, BG_BRIGHT, BG_BRIGHT, 1F);
		ctx.drawTexture(BG[a], 0, 0, 0, 0, BG_W, BG_H, BG_W, BG_H);
		if (crossfade) {
			ctx.setShaderColor(BG_BRIGHT, BG_BRIGHT, BG_BRIGHT, frac);
			ctx.drawTexture(BG[b], 0, 0, 0, 0, BG_W, BG_H, BG_W, BG_H);
		}
		m.pop();

		if (x0 > 0.5F) {
			// extension izquierda (su borde derecho se desvanece sobre el GIF)
			m.push();
			m.translate(ex, 0F, 0F);
			m.scale(es, es, 1F);
			ctx.setShaderColor(BG_BRIGHT, BG_BRIGHT, BG_BRIGHT, 1F);
			ctx.drawTexture(BG_LEFT, 0, 0, 0, 0, EXT_W, EXT_H, EXT_W, EXT_H);
			m.pop();
		}
		ctx.setShaderColor(1F, 1F, 1F, 1F);
	}

	/** Ruleta: entra con "pop", flota, se balancea, respira, resplandece y le salen truenos rojos animados. */
	private void drawLogo(DrawContext ctx, float t) {
		float w = this.width;
		float h = this.height;

		float appear = clamp01((t - 0.10F) / 0.80F);
		if (appear <= 0F) {
			return;
		}
		float alpha = clamp01(appear * 1.6F);
		float pop = 0.60F + 0.40F * easeOutBack(appear);

		float pulse = 0.5F + 0.5F * (float) Math.sin(t * 2.4D);
		float zapBase = (float) (Math.sin(t * 9.0D) * Math.sin(t * 3.7D + 1.0D));
		float zap = zapBase > 0F ? (float) Math.pow(zapBase, 6.0D) : 0F;
		float charge = computeBolts(t);

		float scale = (h * LOGO_SIZE / LOGO_W) * pop * (1F + 0.018F * (float) Math.sin(t * 2.1D));
		float cx = w * COL_X;
		float cy = h * LOGO_CY + (float) Math.sin(t * 1.3D) * h * 0.008F;
		float rot = (float) Math.sin(t * 0.8D) * 1.6F;

		MatrixStack m = ctx.getMatrices();
		m.push();
		m.translate(cx, cy, 0F);
		m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rot));
		m.scale(scale, scale, 1F);
		m.translate(-LOGO_W / 2F, -LOGO_H / 2F, 0F);

		// resplandor rojo detras (se enciende con los truenos)
		float haloAlpha = clamp01(alpha * (0.20F + 0.22F * pulse + 0.45F * zap + 0.50F * charge));
		m.push();
		m.translate(LOGO_W / 2F, LOGO_H / 2F, 0F);
		m.scale(1.07F, 1.07F, 1F);
		m.translate(-LOGO_W / 2F, -LOGO_H / 2F, 0F);
		ctx.setShaderColor(1.0F, 0.16F, 0.10F, haloAlpha);
		ctx.drawTexture(LOGO, 0, 0, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);
		m.pop();

		// ruleta
		float br = 1.0F + 0.08F * pulse + 0.30F * zap + 0.18F * charge;
		ctx.setShaderColor(br, br, br, alpha);
		ctx.drawTexture(LOGO, 0, 0, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);

		// truenos (en las mismas coordenadas de la ruleta)
		for (int i = 0; i < this.boltN; i++) {
			drawBolt(ctx, m, this.bVar[i], this.bAng[i], this.bScale[i], this.bAlpha[i] * alpha, this.bBright[i]);
		}

		m.pop();
		ctx.setShaderColor(1F, 1F, 1F, 1F);
	}

	/**
	 * Calcula (sin estado) que truenos estan prendidos en el instante t.
	 * Devuelve la "carga" electrica 0..1 para sincronizar el resplandor.
	 */
	private float computeBolts(float t) {
		this.boltN = 0;
		float charge = 0F;

		// truenos al azar: cada "carril" dispara a su ritmo, el trueno cambia de forma ~22 veces por segundo
		for (int i = 0; i < LANES; i++) {
			float p = LANE_PERIOD[i];
			float x = t / p + LANE_OFFSET[i];
			int cycle = (int) Math.floor(x);
			float phase = (x - cycle) * p;
			float life = 0.17F + 0.10F * hash01(cycle, i * 7 + 1);
			if (phase >= life) {
				continue;
			}
			float u = phase / life;
			float env = u < 0.12F ? u / 0.12F : 1F - (u - 0.12F) / 0.88F;
			env *= env;
			float flick = 0.72F + 0.28F * (float) Math.sin(phase * 140.0D + i * 2.0D);
			float r = hash01(cycle, i * 7 + 2);
			int start = r < 0.55F ? G_RADIAL : (r < 0.85F ? G_RIM : G_SKULL);
			int size = r < 0.55F ? N_RADIAL : (r < 0.85F ? N_RIM : N_SKULL);
			int step = (int) (phase / 0.045F);
			int variant = start + ((int) (hash01(cycle, i * 7 + 3) * size) + step) % size;
			addBolt(variant, hash01(cycle, i * 7 + 4) * 360F, 0.90F + 0.30F * hash01(cycle, i * 7 + 5),
				env * flick, 1F + 0.5F * env);
			charge += env * 0.45F;
		}

		// tormenta: cada ~3.7 s una rafaga de truenos rapidos
		float storm = (float) Math.pow(Math.max(0.0D, Math.sin(t * 1.7D + 0.8D)), 10.0D);
		if (storm > 0.12F) {
			for (int k = 0; k < 4; k++) {
				float p = 0.075F;
				float x = t / p + k * 0.37F;
				int cycle = (int) Math.floor(x);
				float phase = (x - cycle) * p;
				if (phase > 0.058F) {
					continue;
				}
				int variant = G_RADIAL + (int) (hash01(cycle, 100 + k) * (N_RADIAL + N_SKULL));
				if (variant >= N_RADIAL) {
					variant += G_SKULL - N_RADIAL;
				}
				addBolt(variant, hash01(cycle, 120 + k) * 360F, 1.0F + 0.2F * hash01(cycle, 140 + k),
					storm * (0.75F + 0.25F * (float) Math.sin(phase * 200.0D)), 1.4F);
			}
			charge += storm;
		}

		// corriente electrica que le da vueltas al borde de la ruleta (siempre prendida, suave)
		for (int layer = 0; layer < 2; layer++) {
			int variant = G_RIM + ((int) (t / 0.06F) + layer * 3) % N_RIM;
			float ang = t * (layer == 0 ? 55F : -38F) + layer * 170F;
			float al = 0.38F + 0.14F * (float) Math.sin(t * 3.1D + layer * 2.0D);
			addBolt(variant, ang, 1F, al, 1.1F);
		}
		return clamp01(charge);
	}

	private void addBolt(int variant, float angleDeg, float scale, float alpha, float bright) {
		if (this.boltN >= MAX_BOLTS || alpha <= 0.01F) {
			return;
		}
		int i = this.boltN++;
		this.bVar[i] = variant;
		this.bAng[i] = angleDeg;
		this.bScale[i] = scale;
		this.bAlpha[i] = alpha;
		this.bBright[i] = bright;
	}

	private void drawBolt(DrawContext ctx, MatrixStack m, int variant, float angleDeg, float scale, float alpha, float bright) {
		float a = clamp01(alpha);
		if (a <= 0.01F) {
			return;
		}
		m.push();
		m.translate(WHEEL_CX, WHEEL_CY, 0F);
		m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angleDeg));
		m.scale(2F * scale, 2F * scale, 1F);
		m.translate(-BOLT_SIZE / 2F, -BOLT_SIZE / 2F, 0F);
		ctx.setShaderColor(bright, bright, bright, a);
		ctx.drawTexture(BOLTS[variant], 0, 0, 0, 0, BOLT_SIZE, BOLT_SIZE, BOLT_SIZE, BOLT_SIZE);
		m.pop();
	}

	/** Botones: aparecen uno por uno, y al pasar el mouse crecen, brillan y sale una linea de color. */
	private void drawButtons(DrawContext ctx, int mouseX, int mouseY, float t, float dt) {
		float w = this.width;
		float h = this.height;
		float k = h * BTN_K;
		float cx = w * COL_X;
		MatrixStack m = ctx.getMatrices();

		for (int i = 0; i < this.btns.length; i++) {
			Btn b = this.btns[i];
			float p = clamp01((t - (0.55F + 0.14F * i)) / 0.45F);
			if (p <= 0F) {
				continue;
			}
			float a = easeOutCubic(p);
			boolean over = p >= 1F && isOver(b, mouseX, mouseY);
			b.hover += ((over ? 1F : 0F) - b.hover) * Math.min(1F, dt * 14F);

			float idle = 1F + 0.010F * (float) Math.sin(t * 2.0D + i * 1.3D);
			float s = k * idle * (1F + 0.14F * b.hover);
			float bright = 1F + 0.40F * b.hover;
			float cy = h * b.yFrac + (1F - a) * h * 0.03F;

			m.push();
			m.translate(cx, cy, 0F);
			m.scale(s, s, 1F);
			m.translate(-b.tw / 2F, -b.th / 2F, 0F);
			ctx.setShaderColor(bright, bright, bright, a);
			ctx.drawTexture(b.tex, 0, 0, 0, 0, b.tw, b.th, b.tw, b.th);
			m.pop();

			// linea de color debajo (solo con hover)
			if (b.hover > 0.02F) {
				float halfLine = b.tw * s * 0.5F * 0.94F * easeOutCubic(clamp01(b.hover));
				int ly = Math.round(cy + b.th * s * 0.5F + h * 0.006F);
				int thick = Math.max(1, (int) (h * 0.0028F));
				int la = (int) (255F * clamp01(b.hover) * a);
				if (la > 8) {
					ctx.fill(Math.round(cx - halfLine), ly, Math.round(cx + halfLine), ly + thick, (la << 24) | b.rgb);
				}
			}
		}
		ctx.setShaderColor(1F, 1F, 1F, 1F);
	}

	/** "created by SEFIX": entra deslizando, palpita y un brillo le cruza las letras cada tanto. */
	private void drawCredit(DrawContext ctx, float t) {
		float w = this.width;
		float h = this.height;
		float appear = clamp01((t - 1.0F) / 0.7F);
		if (appear <= 0F) {
			return;
		}
		float a = easeOutCubic(appear);

		float cw = h * CREDIT_SIZE;
		float s = cw / CREDIT_W;
		float ch = CREDIT_H * s;
		float x = w - cw - h * 0.022F + (1F - a) * h * 0.04F;
		float y = h - ch - h * 0.016F;
		float pulse = 1F + 0.06F * (float) Math.sin(t * 2.2D);

		MatrixStack m = ctx.getMatrices();
		m.push();
		m.translate(x, y, 0F);
		m.scale(s, s, 1F);
		ctx.setShaderColor(pulse, pulse, pulse, a);
		ctx.drawTexture(CREDIT, 0, 0, 0, 0, CREDIT_W, CREDIT_H, CREDIT_W, CREDIT_H);
		m.pop();

		// brillo que barre las letras (solo cuando ya termino de entrar)
		if (appear >= 1F && t > 1.9F) {
			float cyc = ((t - 1.9F) % SHINE_PERIOD) / SHINE_DUR;
			if (cyc < 1F) {
				float bx = x + (cyc * 1.3F - 0.15F) * cw;
				int top = Math.round(y);
				int bottom = Math.round(y + ch);
				for (int i = 0; i < SHINE_WIDTH.length; i++) {
					int half = Math.max(1, Math.round(cw * SHINE_WIDTH[i] * 0.5F));
					int x1 = Math.round(bx) - half;
					int x2 = Math.round(bx) + half;
					ctx.enableScissor(x1, top, x2, bottom);
					m.push();
					m.translate(x, y, 0F);
					m.scale(s, s, 1F);
					ctx.setShaderColor(2.2F, 2.0F, 1.9F, SHINE_ALPHA[i]);
					ctx.drawTexture(CREDIT, 0, 0, 0, 0, CREDIT_W, CREDIT_H, CREDIT_W, CREDIT_H);
					m.pop();
					ctx.disableScissor();
				}
			}
		}
		ctx.setShaderColor(1F, 1F, 1F, 1F);
	}

	/** Entrada: la pantalla sale de negro. */
	private void drawFade(DrawContext ctx, float t) {
		float f = 1F - clamp01(t / 0.7F);
		int alpha = (int) (255F * f);
		if (alpha > 2) {
			ctx.fill(0, 0, this.width, this.height, alpha << 24);
		}
	}

	// ------------------------------------------------------------------
	// Utilidades
	// ------------------------------------------------------------------
	/** Numero "al azar" repetible en [0,1) a partir de dos enteros. */
	private static float hash01(int a, int b) {
		int h = a * 0x27D4EB2D + b * 0x165667B1 + 0x9E3779B9;
		h ^= h >>> 15;
		h *= 0x85EBCA6B;
		h ^= h >>> 13;
		h *= 0xC2B2AE35;
		h ^= h >>> 16;
		return (h >>> 8) / 16777216.0F;
	}

	private static float clamp(float v, float min, float max) {
		return v < min ? min : (v > max ? max : v);
	}

	private static float clamp01(float v) {
		return clamp(v, 0F, 1F);
	}

	private static float easeOutCubic(float p) {
		float q = 1F - p;
		return 1F - q * q * q;
	}

	private static float easeOutBack(float p) {
		final float c1 = 1.70158F;
		final float c3 = c1 + 1F;
		float q = p - 1F;
		return 1F + c3 * q * q * q + c1 * q * q;
	}
}

package com.sefix.desafio4;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Desafio4Mod implements ClientModInitializer {
	public static final String MOD_ID = "desafio4_menu";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitializeClient() {
		LOGGER.info("Menu Desafio 4 cargado (created by sefix)");
	}
}
